n = int(input("Enter the order of the square matrix: "))
A = []
print("\nEnter the matrix elements row-wise:")
print("Example for 3x3 matrix: 1 2 3")
for i in range(n):
    row = input(f"Row {i+1}: ").split()
    if len(row) != n:
        print("Invalid row size!")
        exit()
    A.append([float(x) for x in row])
original = [row[:] for row in A]
I = []
for i in range(n):
    row = []
    for j in range(n):
        if i == j:
            row.append(1.0)
        else:
            row.append(0.0)
    I.append(row)
aug = []
for i in range(n):
    aug.append(A[i] + I[i])
for i in range(n):
    if aug[i][i] == 0:
        print("\nInverse does not exist (Zero Pivot).")
        exit()
    pivot = aug[i][i]
    for j in range(2*n):
        aug[i][j] = aug[i][j] / pivot
    for k in range(n):
        if k != i:
            factor = aug[k][i]
            for j in range(2*n):
                aug[k][j] = aug[k][j] - factor * aug[i][j]
inverse = []
for i in range(n):
    row = []
    for j in range(n, 2*n):
        row.append(aug[i][j])
    inverse.append(row)
print("\nInverse Matrix:")
for row in inverse:
    for value in row:
        print(f"{value:.2f}", end="\t")
    print()
result = []
for i in range(n):
    row = []
    for j in range(n):
        total = 0
        for k in range(n):
            total += original[i][k] * inverse[k][j]
        row.append(total)
    result.append(row)
print("\nVerification (Original × Inverse):")
for row in result:
    for value in row:
        print(f"{value:.2f}", end="\t")
    print()
