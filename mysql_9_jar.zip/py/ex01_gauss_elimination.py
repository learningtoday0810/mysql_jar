n = int(input("Enter n: "))
a = []
print("Enter the ele of coefficient matrix:")
for i in range(n):
    a.append(list(map(int, input().split())))
b = list(map(int, input("Enter the constant terms: ").split()))
for k in range(n - 1):
    for i in range(k + 1, n):
        m = a[i][k] / a[k][k]
        for j in range(k, n):
            a[i][j] = a[i][j] - m * a[k][j]
        b[i] = b[i] - m * b[k]
x = [0] * n
x[n - 1] = b[n - 1] / a[n - 1][n - 1]
for i in range(n - 2, -1, -1):
    s = 0
    for j in range(i + 1, n):
        s = s + a[i][j] * x[j]
    x[i] = (b[i] - s) / a[i][i]
print("\nSolution:")
for i in range(n):
    print("x", i + 1, "=", round(x[i]))

import matplotlib.pyplot as plt

plt.plot(range(1, n + 1), x, marker='o')
plt.xlabel("Variable Number")
plt.ylabel("Solution Value")
plt.title("Gaussian Elimination")
plt.grid(True)
plt.show()