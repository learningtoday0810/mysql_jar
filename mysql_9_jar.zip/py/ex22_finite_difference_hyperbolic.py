import numpy as np
import re
import math

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    """Formats mathematical strings like 2x -> 2*x, 100sin(pi*x) -> 100*sin(pi*x)."""
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', raw_expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    return expr.strip()

print("=" * 68)
print("  EXPLICIT FINITE DIFFERENCE SOLVER FOR HYPERBOLIC WAVE EQUATION  ")
print("                  Equation: u_tt = c^2 * u_xx                     ")
print("=" * 68)

# 1. Physical and Mesh Domain Inputs (Pages 2, 5)
L = float(input("Enter string/domain length L (e.g., 1.0): "))
T = float(input("Enter total simulation time T (e.g., 0.001 or 0.1): "))
c = float(input("Enter wave speed c (e.g., 100.0 or 1.0): "))
M = int(input("Enter number of spatial intervals M (e.g., 4, 10, or 100): "))
N = int(input("Enter number of time steps N (e.g., 4 or 20): "))

# Step sizes and Courant condition (Pages 2, 3)
h = L / M
k = T / N
r = (c * k) / h
x_nodes = np.linspace(0, L, M + 1)

print(f"\nComputed Parameters:")
print(f"  Spatial step (h) = {h:.6f}")
print(f"  Time step (k)    = {k:.6f}")
print(f"  Courant number r = {r:.6f}")

if r > 1.0:
    print(f"  [WARNING]: r = {r:.4f} > 1.0. CFL Stability condition violated! Solution will diverge.")
else:
    print("  [STABLE]: r <= 1.0 satisfies Courant-Friedrichs-Lewy (CFL) stability condition.")

# 2. Boundary Conditions u(0, t) and u(L, t)
print("\n--- Boundary Conditions ---")
left_bc_expr = clean_expression(input("Enter left boundary u(0, t) [e.g. 0]: ") or "0")
right_bc_expr = clean_expression(input(f"Enter right boundary u({L}, t) [e.g. 0]: ") or "0")

def g0(t_val):
    env = math_env.copy()
    env["t"] = t_val
    return float(eval(left_bc_expr, {"__builtins__": {}}, env))

def gL(t_val):
    env = math_env.copy()
    env["t"] = t_val
    return float(eval(right_bc_expr, {"__builtins__": {}}, env))

# 3. Initial Displacement u(x, 0) = f(x)
print("\n--- Initial Displacement u(x, 0) = f(x) ---")
print("1. Enter an algebraic formula (e.g., 0.01*sin(pi*x), sin(pi*x))")
print("2. Enter point-by-point manual values")
init_choice = input("Select choice (1 or 2): ").strip()

f_vals = np.zeros(M + 1)
if init_choice == "1":
    f_expr = clean_expression(input("Enter formula for f(x): "))
    for i in range(M + 1):
        env = math_env.copy()
        env["x"] = x_nodes[i]
        f_vals[i] = float(eval(f_expr, {"__builtins__": {}}, env))
else:
    print(f"Enter {M + 1} values for initial displacement f(x):")
    for i in range(M + 1):
        f_vals[i] = float(input(f"  f(x = {x_nodes[i]:.4f}): "))

# 4. Initial Velocity u_t(x, 0) = g(x) (Pages 1, 4)
print("\n--- Initial Velocity u_t(x, 0) = g(x) ---")
g_expr_raw = input("Enter formula for g(x) [press Enter for zero initial velocity 0]: ").strip()
g_expr = clean_expression(g_expr_raw) if g_expr_raw else "0"

g_vals = np.zeros(M + 1)
for i in range(M + 1):
    env = math_env.copy()
    env["x"] = x_nodes[i]
    g_vals[i] = float(eval(g_expr, {"__builtins__": {}}, env))

# Allocate 2D grid: U[time_step n, space_node i]
U = np.zeros((N + 1, M + 1))

# Set initial level n = 0 (Page 5)
U[0, :] = f_vals.copy()
U[0, 0] = g0(0.0)
U[0, M] = gL(0.0)

# 5. First Time Level n = 1 (Special Formula from Page 4)
# U_i^1 = f(x_i) + k*g(x_i) + 0.5 * r^2 * [f(x_{i+1}) - 2*f(x_i) + f(x_{i-1})]
t_1 = 1 * k
U[1, 0] = g0(t_1)
U[1, M] = gL(t_1)

for i in range(1, M):
    U[1, i] = (
        f_vals[i]
        + k * g_vals[i]
        + 0.5 * (r**2) * (f_vals[i + 1] - 2.0 * f_vals[i] + f_vals[i - 1])
    )

# 6. Main Explicit Central-Difference Time Marching (Pages 3, 5, 6)
# U_i^{n+1} = 2*(1 - r^2)*U_i^n + r^2*(U_{i-1}^n + U_{i+1}^n) - U_i^{n-1}
for n in range(1, N):
    t_next = (n + 1) * k
    U[n + 1, 0] = g0(t_next)
    U[n + 1, M] = gL(t_next)
    
    for i in range(1, M):
        U[n + 1, i] = (
            2.0 * (1.0 - r**2) * U[n, i]
            + (r**2) * (U[n, i - 1] + U[n, i + 1])
            - U[n - 1, i]
        )

# 7. Formatted Table Output Matching Exam & Lab Requirements
print("\n" + "=" * 78)
print("             WAVE EQUATION SOLUTION TABLE: u(x, t)                ")
print("=" * 78)

# Table Header
header = f"{'Time Level':<14} | " + " | ".join([f"x={x_nodes[i]:<6.3f}" for i in range(M + 1)])
print(header)
print("-" * len(header))

# Display from final time down to t = 0
for n in range(N, -1, -1):
    t_val = n * k
    row_str = " | ".join([f"{U[n, i]:8.5f}" for i in range(M + 1)])
    print(f"n={n:<2} (t={t_val:.5f}) | {row_str}")

print("=" * len(header))
print(f"\nFinal Displacement Vector at t = {T:.5f} (n = {N}):")
print(np.round(U[N, :], 6))

import matplotlib.pyplot as plt

for i in range(0, N + 1, max(1, N // 5)):
    plt.plot(x_nodes, U[i, :], marker='o',
             label=f't = {i*k:.5f}')

plt.xlabel('Position (x)')
plt.ylabel('Displacement u(x,t)')
plt.title('Wave Equation - Displacement at Different Times')
plt.grid(True)
plt.legend()
plt.show()

'''
Enter string/domain length L: 1
Enter total simulation time T: 0.1
Enter wave speed c: 1
Enter number of spatial intervals M: 4
Enter number of time steps N: 4

Enter left boundary u(0, t): 0
Enter right boundary u(1, t): 0

Select choice (1 or 2): 1
Enter formula for f(x): sin(pi*x)

Enter formula for g(x): 0
'''


'''
import numpy as np

L = 1.0
c = 100.0
M = 100
h = L / M
T = 0.001
k = 5e-5
N = int(T / k)
r = (c * k) / h
print(f"Courant number r = {r}")
if r > 1.0:
    print("Warning: Stability condition violated!")
else:
    print("Stability condition satisfied.")
x = np.array([i * h for i in range(M + 1)])
U_prev = 0.01 * np.sin(np.pi * x)
U_curr = np.zeros_like(U_prev)
U_curr[0] = 0.0
U_curr[M] = 0.0
for i in range(1, M):
    U_curr[i] = U_prev[i] + (r**2 / 2.0) * (U_prev[i + 1] - 2 * U_prev[i] + U_prev[i - 1])
for n in range(1, N):
    U_next = np.zeros_like(U_curr)
    U_next[0] = 0.0
    U_next[M] = 0.0
    for i in range(1, M):
        U_next[i] = (2 * (1 - r**2) * U_curr[i] + r**2 * (U_curr[i - 1] + U_curr[i + 1]) - U_prev[i])
    U_prev = U_curr.copy()
    U_curr = U_next.copy()
print("\nFinal Displacement U:")
print(U_curr)
'''