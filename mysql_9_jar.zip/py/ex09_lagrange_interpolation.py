# Calculates the Lagrange polynomial, converts it into standard polynomial form, calculates operation costs, and finds the breakeven point.

import sympy as sp

n = int(input("Enter number of points (e.g. 4): "))
print("Enter each point as 'x y' on a new line (e.g. 2 1):")
pts = [list(map(float, input(f"Point {i+1}: ").split())) for i in range(n)]
x_pts, y_pts = [p[0] for p in pts], [p[1] for p in pts]
x_target = float(input("\nEnter x to interpolate (e.g. 6.5): "))
x = sp.Symbol('x')
lagrange_terms = []
lagrange_expr = 0
for i in range(n):
    num_factors = [f"(x - {int(x_pts[j]) if x_pts[j].is_integer() else x_pts[j]})" for j in range(n) if j != i]
    denom = 1
    for j in range(n):
        if j != i:
            denom *= (x_pts[i] - x_pts[j])
    coeff = sp.nsimplify(y_pts[i] / denom)
    term_str = f"({coeff})*" + "*".join(num_factors)
    lagrange_terms.append(term_str)
    basis = sp.prod([(x - x_pts[j]) / (x_pts[i] - x_pts[j]) for j in range(n) if j != i])
    lagrange_expr += sp.nsimplify(y_pts[i]) * sp.nsimplify(basis)
P_std = sp.Poly(sp.expand(lagrange_expr), x)
ops_scratch = n * ((n - 1) * 4 + 2)
ops_counted = ops_scratch - 1
ops_precomp = n * (2 * n - 2) + (n - 1)
ops_d = 60
ops_e = 9
be = ops_d / (ops_counted - ops_e)
val = float(P_std.as_expr().subs(x, x_target))
print(f"Points entered: {pts}")
print(f"Interpolated Value P({x_target}): {val:.6f}")
print("a. Lagrange Form :")
print("   P(x) = " + " +\n          ".join(lagrange_terms))
print(f"\nb. Standard Form : P(x) = {P_std.as_expr()}")
print(f"c. Direct Lagrange  : {ops_scratch} ops (or {ops_counted} ops)")
print(f"   Precomputed      : {ops_precomp} ops")
print(f"d. Conversion Cost  : ~{ops_d} ops")
print(f"e. Standard Form    : {ops_e} ops")
print(f"f. Breakeven Interpolations: {int(be) + 1}")
