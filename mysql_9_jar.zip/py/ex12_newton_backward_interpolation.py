import numpy as np
import matplotlib.pyplot as plt

# Function to calculate backward difference table
def backward_difference_table(y):
    n = len(y)
    diff = [[0.0] * n for _ in range(n)]

    for i in range(n):
        diff[i][0] = y[i]

    for j in range(1, n):
        for i in range(j, n):
            diff[i][j] = diff[i][j-1] - diff[i-1][j-1]

    return diff


# Function to perform Newton backward interpolation
def backward_interpolation(x, y, value, diff):
    n = len(x)
    h = x[1] - x[0]

    u = (value - x[-1]) / h

    result = y[-1]
    term = 1

    for i in range(1, n):
        term *= (u + i - 1) / i
        result += term * diff[n-1][i]

    return result


# Input
n = int(input("Enter number of data points: "))

x = []
y = []

for i in range(n):
    x_val = float(input("Enter x value: "))
    y_val = float(input("Enter y value: "))

    x.append(x_val)
    y.append(y_val)

value = float(input("Enter interpolation value: "))


# Check equal spacing
h = x[1] - x[0]

if not np.allclose(np.diff(x), h):
    print("Error: x values must be equally spaced.")

else:
    # Calculate difference table
    diff = backward_difference_table(y)

    # Display difference table
    print("\nBackward Difference Table")
    print("x\t y\t ∇1\t ∇2\t ∇3")

    for i in range(n):
        print(f"{x[i]:.3f}", end="\t")

        for j in range(n - i):
            print(f"{diff[i][j]:.4f}", end="\t")

        print()

    # Calculate interpolated value
    answer = backward_interpolation(x, y, value, diff)

    print("\nInterpolated value =", round(answer, 4))

    # Plot graph
    x_curve = np.linspace(min(x), max(x), 200)

    y_curve = [
        backward_interpolation(x, y, val, diff)
        for val in x_curve
    ]

    plt.plot(x_curve, y_curve, 'b-', label='Backward Interpolation')
    plt.plot(x, y, 'ro', label='Given Data Points')
    plt.plot(value, answer, 'go', label='Interpolated Point')

    plt.xlabel('x')
    plt.ylabel('y')
    plt.title('Newton Backward Interpolation')
    plt.legend()
    plt.grid()
    plt.show()