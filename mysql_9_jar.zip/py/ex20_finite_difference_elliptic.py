import numpy as np
import re

def clean_expression(raw_expr):
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    # Insert implicit multiplications: e.g. 729x**2 -> 729*x**2
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', raw_expr)
    return expr.strip()

print("=" * 65)
print("  FINITE DIFFERENCE BVP SOLVER (UNIT 5: BOUNDARY VALUE PROBLEMS) ")
print("=" * 65)
print("1. 2nd-Order BVP: y'' = p(x)*y' + q(x)*y + r(x)")
print("2. 4th-Order Beam Deflection: y'''' + A*y = phi(x)")
order_choice = input("\nSelect BVP Order (1 or 2): ").strip()

# =====================================================================
# CASE 1: 2nd-ORDER BOUNDARY VALUE PROBLEM
# =====================================================================
if order_choice == "1":
    print("\n--- 2nd-Order BVP: y'' = p(x)*y' + q(x)*y + r(x) ---")
    p_expr = clean_expression(input("Enter p(x) [press Enter for 0]: ") or "0")
    q_expr = clean_expression(input("Enter q(x) [e.g., 1 for y''=x+y]: ") or "1")
    r_expr = clean_expression(input("Enter r(x) [e.g., x for y''=x+y]: ") or "x")

    def p(x): return eval(p_expr, {"__builtins__": {}}, {"x": x})
    def q(x): return eval(q_expr, {"__builtins__": {}}, {"x": x})
    def r(x): return eval(r_expr, {"__builtins__": {}}, {"x": x})

    x0 = float(input("\nEnter left boundary x0: "))
    y0 = float(input("Enter boundary value y(x0): "))
    xn = float(input("Enter right boundary xn: "))
    yn = float(input("Enter boundary value y(xn): "))
    n = int(input("Enter number of subintervals (n): "))

    h = (xn - x0) / n
    num_interior = n - 1
    x = [x0 + i * h for i in range(n + 1)]

    A = np.zeros((num_interior, num_interior))
    B = np.zeros(num_interior)

    # Standard central difference:
    # (1 - h*p/2)*y_{i-1} - (2 + h^2*q)*y_i + (1 + h*p/2)*y_{i+1} = h^2 * r(x_i)
    for i in range(num_interior):
        idx = i + 1
        xi = x[idx]
        pi = p(xi)
        qi = q(xi)
        ri = r(xi)

        A[i, i] = -(2.0 + (h**2) * qi)
        if i > 0:
            A[i, i - 1] = 1.0 - (h * pi / 2.0)
        if i < num_interior - 1:
            A[i, i + 1] = 1.0 + (h * pi / 2.0)

        B[i] = (h**2) * ri
        if i == 0:
            B[i] -= (1.0 - h * pi / 2.0) * y0
        if i == num_interior - 1:
            B[i] -= (1.0 + h * pi / 2.0) * yn

    y_interior = np.linalg.solve(A, B)
    y = [y0] + list(y_interior) + [yn]

# =====================================================================
# CASE 2: 4th-ORDER BEAM DEFLECTION BVP (Problems 11 & 12 in PDF)
# y'''' + A*y = phi(x), with y(0)=y'(0)=0 and y''(1)=y'''(1)=0
# =====================================================================
elif order_choice == "2":
    print("\n--- 4th-Order Beam Deflection BVP ---")
    print("Equation: d^4y/dx^4 + A*y = phi(x)")
    A_coeff = float(input("Enter coefficient of y (e.g., 81): "))
    
    print("\nHow is phi(x) given?")
    print("1. Table of discrete values (like Problem 11 in notes)")
    print("2. Continuous formula (like Problem 12: 729*x**2)")
    phi_type = input("Enter choice (1 or 2): ").strip()

    x0 = 0.0
    xn = 1.0
    n = int(input("Enter number of subintervals n (e.g., 3): "))
    h = (xn - x0) / n
    x = [x0 + i * h for i in range(n + 1)]

    phi_vals = [0.0] * (n + 1)
    if phi_type == "1":
        print(f"Enter phi(x) values for the interior points:")
        for i in range(1, n + 1):
            phi_vals[i] = float(input(f"  phi(x_{i} = {x[i]:.4f}): "))
    else:
        phi_expr = clean_expression(input("Enter expression for phi(x) [e.g. 729*x**2]: "))
        for i in range(1, n + 1):
            phi_vals[i] = eval(phi_expr, {"__builtins__": {}}, {"x": x[i]})

    # Fourth order central difference: (1/h^4) [y_{i+2} - 4y_{i+1} + 6y_i - 4y_{i-1} + y_{i-2}] + A*y_i = phi(x_i)
    # Rearranging: y_{i+2} - 4y_{i+1} + (6 + A*h^4)y_i - 4y_{i-1} + y_{i-2} = h^4 * phi(x_i)
    diag_coeff = 6.0 + A_coeff * (h**4)

    # For standard cantilever boundary conditions: y(0)=0, y'(0)=0, y''(1)=0, y'''(1)=0:
    # 1. At i=1: (diag_coeff + 1)*y1 - 4*y2 + y3 = h^4 * phi(x1)
    # 2. At i=2: -2*y1 + 3*y2 - y3 = (h^4 * phi(x2)) / 2
    # 3. At i=3: 2*y1 - 4*y2 + 3*y3 = h^4 * phi(x3)
    # This sets up the exact 3x3 augmented matrix from pages 4 and 7 of the PDF:
    M = np.array([
        [diag_coeff + 1.0, -4.0, 1.0],
        [-2.0, 3.0, -1.0],
        [2.0, -4.0, 3.0]
    ], dtype=float)

    rhs = np.array([
        (h**4) * phi_vals[1],
        ((h**4) * phi_vals[2]) / 2.0,
        (h**4) * phi_vals[3]
    ], dtype=float)

    y_interior = np.linalg.solve(M, rhs)
    y = [0.0] + list(y_interior)

else:
    print("Invalid choice.")
    raise SystemExit

# Display Results
print("\n" + "=" * 45)
print(f"{'Node':<6} | {'x':<10} | {'y(x)':<15}")
print("-" * 45)
for i in range(len(y)):
    print(f"y_{i:<4} | {x[i]:<10.4f} | {y[i]:<15.6f}")
print("=" * 45)

import matplotlib.pyplot as plt

plt.plot(x, y, marker='o', linestyle='-', color='blue',
         label='Numerical Solution')

plt.xlabel('x')
plt.ylabel('y(x)')
plt.title('Boundary Value Problem - Finite Difference Method')
plt.grid(True)
plt.legend()
plt.show()


'''
Select BVP Order (1 or 2): 1

Enter p(x) [press Enter for 0]: 0
Enter q(x) [e.g., 1 for y''=x+y]: 0
Enter r(x) [e.g., x for y''=x+y]: 0

Enter left boundary x0: 0
Enter boundary value y(x0): 0
Enter right boundary xn: 1
Enter boundary value y(xn): 1
Enter number of subintervals (n): 4
'''