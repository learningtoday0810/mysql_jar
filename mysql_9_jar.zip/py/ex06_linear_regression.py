import numpy as np
import matplotlib.pyplot as plt

t = np.array([
    2.5,3.0,3.2,4.0,4.5,4.8,5.0,5.2,5.5,6.0,6.2,6.5,7.0,7.1,7.5,8.0,8.3,8.5,9.0,9.2,9.5,10.0,10.2,10.5,11.0,2.8,3.5,3.8,4.2,4.7,
    5.1,5.3,5.8,6.1,6.4,6.8,7.2,7.4,7.8,8.1,8.4,8.8,9.1,9.4,9.8,10.1,10.4,10.8,11.2,11.5])
y = np.array([
    53,56,58,62,61,65,68,67,72,70,75,73,78,82,79,83,81,86,88,85,92,90,94,93,97,54,60,59,64,63,69,71,68,74,76,75,80,
    83,81,85,84,89,87,91,93,96,95,98,99,100])
print(len(t), len(y))


def gauss_elimination(A, b):
    A = A.astype(float)
    b = b.astype(float)
    n = len(b)
    for i in range(n):
        max_row = np.argmax(abs(A[i:, i])) + i
        if max_row != i:
            A[[i, max_row]] = A[[max_row, i]]
            b[[i, max_row]] = b[[max_row, i]]
        for j in range(i + 1, n):
            factor = A[j][i] / A[i][i]
            A[j] -= factor * A[i]
            b[j] -= factor * b[i]
    x = np.zeros(n)
    for i in range(n - 1, -1, -1):
        x[i] = (b[i] - np.dot(A[i][i + 1:], x[i + 1:])) / A[i][i]
    return x


def gauss_jacobi(A, b, tol=1e-10, max_iter=1000):
    n = len(b)
    x = np.zeros(n)
    D = np.diag(A)
    R = A - np.diagflat(D)
    for _ in range(max_iter):
        x_new = (b - np.dot(R, x)) / D
        if np.linalg.norm(x_new - x, ord=np.inf) < tol:
            return x_new
        x = x_new
    return x


def gauss_seidel(A, b, tol=1e-10, max_iter=1000):
    n = len(b)
    x = np.zeros(n)
    for _ in range(max_iter):
        x_old = x.copy()
        for i in range(n):
            s1 = np.dot(A[i][:i], x[:i])
            s2 = np.dot(A[i][i + 1:], x_old[i + 1:])
            x[i] = (b[i] - s1 - s2) / A[i][i]
        if np.linalg.norm(x - x_old, ord=np.inf) < tol:
            return x
    return x


def design_matrix(t, degree):
    if degree == 1:
        return np.column_stack((t, np.ones(len(t))))
    elif degree == 2:
        return np.column_stack((t**2, t, np.ones(len(t))))
    elif degree == 3:
        return np.column_stack((t**3, t**2, t, np.ones(len(t))))


degrees = [1, 2, 3]
titles = ["Linear Fit", "Quadratic Fit", "Cubic Fit"]
for degree, title in zip(degrees, titles):
    A = design_matrix(t, degree)
    ATA = A.T @ A
    ATy = A.T @ y
    print(title)
    x1 = gauss_elimination(ATA.copy(), ATy.copy())
    x2 = gauss_jacobi(ATA.copy(), ATy.copy())
    x3 = gauss_seidel(ATA.copy(), ATy.copy())
    print("\nGauss Elimination:", x1)
    print("\nGauss Jacobi:", x2)
    print("\nGauss Seidel:", x3)
    xx = np.linspace(min(t), max(t), 300)
    if degree == 1:
        yy = x1[0]*xx + x1[1]
    elif degree == 2:
        yy = x1[0]*xx**2 + x1[1]*xx + x1[2]
    else:
        yy = x1[0]*xx**3 + x1[1]*xx**2 + x1[2]*xx + x1[3]
    plt.figure(figsize=(7, 5))
    plt.scatter(t, y, color='red', label="Data")
    plt.plot(xx, yy, linewidth=2, label=title)
    plt.title(title)
    plt.xlabel("Study Hours")
    plt.ylabel("Exam Score")
    plt.grid(True)
    plt.legend()
    plt.show()
