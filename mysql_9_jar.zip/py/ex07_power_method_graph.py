
import matplotlib.pyplot as plt
import math

def power_method():
    n = int(input("Enter the order of matrix: "))

    print("\nEnter matrix A:")
    A = []
    for i in range(n):
        row = list(map(float, input(f"Row {i+1}: ").split()))
        if len(row) != n:
            print("Invalid row size!")
            return
        A.append(row)

    print("\nEnter the initial vector:")
    V = list(map(float, input().split()))

    if len(V) != n:
        print("Invalid vector size!")
        return

    TOL = 0.0001
    KMAX = 1000

    lam = 0.0
    iterations = []
    eigenvalues = []
    errors = []

    TAG = True
    k = 1

    print("\nInitial Vector:", V)

    while k <= KMAX and TAG:

        W = []
        for i in range(n):
            s = 0
            for j in range(n):
                s += A[i][j] * V[j]
            W.append(s)

        # Find largest absolute component
        c1 = max(abs(x) for x in W)

        if c1 == 0 or not math.isfinite(c1):
            print("\n[STOP] Cannot continue iteration.")
            break

        # Normalize vector
        NewV = [x / c1 for x in W]

        # Calculate signed eigenvalue using Rayleigh quotient
        AV = []
        for i in range(n):
            AV.append(sum(A[i][j] * NewV[j] for j in range(n)))

        numerator = sum(NewV[i] * AV[i] for i in range(n))
        denominator = sum(x * x for x in NewV)

        new_lam = numerator / denominator

        # Sign-independent eigenvector error
        error1 = math.sqrt(sum(
            (V[i] - NewV[i]) ** 2 for i in range(n)
        ))

        error2 = math.sqrt(sum(
            (V[i] + NewV[i]) ** 2 for i in range(n)
        ))

        eigen_error = min(error1, error2)
        lambda_error = abs(new_lam - lam)

        error = max(lambda_error, eigen_error)

        if not math.isfinite(error) or error > 1e100:
            print("\n[STOP] Method is diverging.")
            break

        V = NewV[:]
        lam = new_lam

        iterations.append(k)
        eigenvalues.append(lam)
        errors.append(error)

        print("\nIteration", k)
        print("Eigen Value =", round(lam, 6))
        print("Eigen Vector =", [round(x, 6) for x in V])
        print("Error =", round(error, 6))

        if error <= TOL:
            TAG = False
            print("\n[SUCCESS] Converged at iteration", k)

        k += 1

    if TAG and k > KMAX:
        print("\n[STOP] Maximum iterations reached.")

    if TAG:
        print("\nNo converged solution obtained.")
    else:
        print("\nDominant Eigen Value =", round(lam, 6))
        print("Associated Eigen Vector =", [round(x, 6) for x in V])

    # Graph 1: Eigenvalue vs Iteration
    if iterations:
        plt.figure(figsize=(8, 5))
        plt.plot(iterations, eigenvalues, marker='o')
        plt.xlabel("Iteration Number")
        plt.ylabel("Eigenvalue")
        plt.title("Power Method - Eigenvalue Convergence")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

        # Graph 2: Error vs Iteration
        plt.figure(figsize=(8, 5))
        plt.plot(iterations, errors, marker='o')
        plt.xlabel("Iteration Number")
        plt.ylabel("Error")
        plt.title("Power Method - Error Convergence")
        plt.grid(True)
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    power_method()
