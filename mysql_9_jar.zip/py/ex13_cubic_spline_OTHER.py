n = int(input("Enter number of data points: "))
x = []
f = []
print("Enter the x values:")
for i in range(n):
    x.append(float(input(f"x[{i}] = ")))
print("Enter the f(x) values:")
for i in range(n):
    f.append(float(input(f"f[{i}] = ")))

h = [x[i + 1] - x[i] for i in range(n - 1)]

# Build equations for second derivatives M (natural spline: M0 = M(n-1) = 0)
A = [[0.0] * n for _ in range(n)]
B = [0.0] * n
A[0][0] = 1
A[n - 1][n - 1] = 1
for i in range(1, n - 1):
    A[i][i - 1] = h[i - 1]
    A[i][i] = 2 * (h[i - 1] + h[i])
    A[i][i + 1] = h[i]
    B[i] = 6 * ((f[i + 1] - f[i]) / h[i] - (f[i] - f[i - 1]) / h[i - 1])

# Gauss elimination
for i in range(n):
    for j in range(i + 1, n):
        factor = A[j][i] / A[i][i]
        for k in range(i, n):
            A[j][k] -= factor * A[i][k]
        B[j] -= factor * B[i]
M = [0.0] * n
for i in range(n - 1, -1, -1):
    s = sum(A[i][j] * M[j] for j in range(i + 1, n))
    M[i] = (B[i] - s) / A[i][i]

print("\nSecond derivatives M:", [round(m, 4) for m in M])

# Helper function to locate interval
def find_interval(val):
    for k in range(n - 1):
        if x[k] <= val <= x[k + 1]:
            return k
    return None

# --- Evaluation of y = S(x) ---
value_y = float(input("\nEnter the value of x to interpolate y: "))
i_y = find_interval(value_y)

if i_y is None:
    print("Value for y is outside the data range.")
else:
    hi = h[i_y]
    S = (M[i_y] * (x[i_y + 1] - value_y) ** 3 / (6 * hi)
         + M[i_y + 1] * (value_y - x[i_y]) ** 3 / (6 * hi)
         + (f[i_y] / hi - M[i_y] * hi / 6) * (x[i_y + 1] - value_y)
         + (f[i_y + 1] / hi - M[i_y + 1] * hi / 6) * (value_y - x[i_y]))
    print(f"Interval used: [{x[i_y]}, {x[i_y + 1]}]")
    print(f"Spline value y at x = {value_y} is {S:.4f}")

# --- Evaluation of y' = S'(x) ---
value_yp = float(input("\nEnter the value of x to calculate y' (derivative): "))
i_yp = find_interval(value_yp)

if i_yp is None:
    print("Value for y' is outside the data range.")
else:
    hi = h[i_yp]
    S_prime = (-M[i_yp] * (x[i_yp + 1] - value_yp) ** 2 / (2 * hi)
               + M[i_yp + 1] * (value_yp - x[i_yp]) ** 2 / (2 * hi)
               - (f[i_yp] / hi - M[i_yp] * hi / 6)
               + (f[i_yp + 1] / hi - M[i_yp + 1] * hi / 6))
    print(f"Interval used: [{x[i_yp]}, {x[i_yp + 1]}]")
    print(f"Spline derivative y' at x = {value_yp} is {S_prime:.4f}")