def divided_differences(x, y):
    dd = [y.copy()]
    for order in range(1, len(y)):
        prev = dd[-1]
        curr = []
        for i in range(len(prev) - 1):
            value = (prev[i + 1] - prev[i]) / (x[i + order] - x[i])
            curr.append(value)
        dd.append(curr)
    return dd


def newton_polynomial(x, dd):
    polynomial = f"{dd[0][0]}"
    for order in range(1, len(dd)):
        coefficient = dd[order][0]
        polynomial += f" + ({coefficient})"
        for j in range(order):
            polynomial += f"(x - {x[j]})"
    return polynomial


def interpolate(x, dd, x_value):
    result = dd[0][0]
    product = 1.0
    for order in range(1, len(dd)):
        product *= (x_value - x[order - 1])
        result += dd[order][0] * product
    return result


n = int(input("Enter number of data points: "))
x = []
y = []
for i in range(n):
    x.append(float(input(f"Enter x[{i}]: ")))
    y.append(float(input(f"Enter y[{i}]: ")))
dd = divided_differences(x, y)
print("\nComplete Divided Difference Table")
print(f"{'x':<10}", end="")
for i in range(len(dd)):
    print(f"{'dd' + str(i):<12}", end="")
print()
for i in range(n):
    print(f"{x[i]:<10.4f}", end="")
    for order in range(len(dd)):
        if i < len(dd[order]):
            print(f"{dd[order][i]:<12.4f}", end="")
        else:
            print(f"{'':<12}", end="")
    print()
polynomial = newton_polynomial(x, dd)
print("\nNewton Interpolation Polynomial")
print("P(x) =", polynomial)
x_value = float(input("\nEnter x value to find y: "))
y_value = interpolate(x, dd, x_value)
print(f"\nFor x = {x_value}")
print(f"y = {y_value}")


import matplotlib.pyplot as plt
import numpy as np

x_curve = np.linspace(min(x), max(x), 200)
y_curve = [interpolate(x, dd, val) for val in x_curve]

plt.plot(x_curve, y_curve, 'b-', label='Newton Interpolation')
plt.plot(x, y, 'ro', label='Given Data Points')
plt.plot(x_value, y_value, 'go', label='Interpolated Point')

plt.xlabel('x')
plt.ylabel('y')
plt.title('Newton Divided Difference Interpolation')
plt.legend()
plt.grid()
plt.show()
