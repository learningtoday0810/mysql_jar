#Directly calculates the interpolated value using the Lagrange formula.

n = int(input("Enter number of points: "))
print("Enter each point as 'x y' on a new line (e.g. 2 1):")
x_pts = []
y_pts = []
for i in range(n):
    px, py = map(float, input(f"Point {i+1}: ").split())
    x_pts.append(px)
    y_pts.append(py)

x_target = float(input("\nEnter x to interpolate: "))

result = 0.0
for i in range(n):
    L = 1.0
    for j in range(n):
        if j != i:
            L *= (x_target - x_pts[j]) / (x_pts[i] - x_pts[j])
    result += y_pts[i] * L

print(f"\nInterpolated Value P({x_target}): {result:.6f}")