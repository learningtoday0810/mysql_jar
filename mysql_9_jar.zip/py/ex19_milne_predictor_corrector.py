
import math
import re
import matplotlib.pyplot as plt

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}


def clean_expression(raw_expr):
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]

    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', raw_expr)
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)

    return expr.strip()


print("=" * 65)
print("        MILNE'S PREDICTOR-CORRECTOR METHOD")
print("=" * 65)

raw_expr = input("Enter equation f(x, y): ")
parsed_expr = clean_expression(raw_expr)

print("Interpreted equation: dy/dx =", parsed_expr)


def f(x, y):
    env = math_env.copy()
    env["x"] = x
    env["y"] = y
    return eval(parsed_expr, {"__builtins__": {}}, env)


print("\nChoose initial values:")
print("1. Only (x0, y0) given - Generate starting values using RK4")
print("2. Four known points are given")

choice = input("Enter choice: ").strip()

x_vals = []
y_vals = []

if choice == "1":

    x0 = float(input("\nEnter x0: "))
    y0 = float(input("Enter y0: "))
    h = float(input("Enter step size h: "))
    xf = float(input("Enter target x: "))

    if h == 0:
        raise ValueError("Step size cannot be zero.")

    direction = 1 if xf >= x0 else -1
    step = direction * abs(h)

    total_steps = int(round((xf - x0) / step))

    x_vals = [x0 + i * step for i in range(total_steps + 1)]
    y_vals = [0.0] * (total_steps + 1)
    y_vals[0] = y0

    # Generate first three points using RK4
    print("\n--- RK4 STARTER VALUES ---")

    for i in range(min(3, total_steps)):

        k1 = step * f(x_vals[i], y_vals[i])

        k2 = step * f(
            x_vals[i] + step / 2,
            y_vals[i] + k1 / 2
        )

        k3 = step * f(
            x_vals[i] + step / 2,
            y_vals[i] + k2 / 2
        )

        k4 = step * f(
            x_vals[i] + step,
            y_vals[i] + k3
        )

        y_vals[i + 1] = y_vals[i] + (
            k1 + 2*k2 + 2*k3 + k4
        ) / 6

        print(
            f"x = {x_vals[i+1]:.4f}, "
            f"y = {y_vals[i+1]:.6f}, "
            f"f(x,y) = {f(x_vals[i+1], y_vals[i+1]):.6f}"
        )

elif choice == "2":

    h = float(input("\nEnter step size h: "))

    print("Enter four known points:")

    for i in range(4):
        xi = float(input(f"x[{i}]: "))
        yi = float(input(f"y[{i}]: "))

        x_vals.append(xi)
        y_vals.append(yi)

    xf = float(input("Enter target x: "))

    direction = 1 if xf >= x_vals[0] else -1
    step = direction * abs(h)

    total_steps = int(round((xf - x_vals[0]) / step))

    if total_steps < 3:
        raise ValueError("Target must be at least the fourth point.")

    for i in range(4, total_steps + 1):
        x_vals.append(x_vals[0] + i * step)
        y_vals.append(0.0)

else:
    raise ValueError("Invalid choice.")

# Calculate initial slopes
F = [f(x_vals[i], y_vals[i]) for i in range(4)]

F += [0.0] * (len(x_vals) - 4)

# Tolerance
eps_input = input(
    "\nEnter tolerance (press Enter for single correction): "
).strip()

eps = float(eps_input) if eps_input else None

print("\n" + "=" * 70)
print("       MILNE'S PREDICTOR-CORRECTOR")
print("=" * 70)

print(f"{'Target x':<12} {'Predictor':<18} {'Corrector':<18}")
print("-" * 70)

# Milne Predictor-Corrector
for n in range(3, total_steps):

    target_x = x_vals[n + 1]

    # Milne Predictor
    y_pred = y_vals[n-3] + (4 * step / 3) * (
        2 * F[n-2]
        - F[n-1]
        + 2 * F[n]
    )

    # Milne Corrector
    if eps is None:

        y_corr = y_vals[n-1] + (step / 3) * (
            F[n-1]
            + 4 * F[n]
            + f(target_x, y_pred)
        )

    else:

        prev = y_pred
        iteration = 0

        while True:

            y_corr = y_vals[n-1] + (step / 3) * (
                F[n-1]
                + 4 * F[n]
                + f(target_x, prev)
            )

            iteration += 1

            if abs(y_corr - prev) < eps or iteration >= 25:
                break

            prev = y_corr

    y_vals[n + 1] = y_corr

    F[n + 1] = f(target_x, y_corr)

    print(
        f"{target_x:<12.4f} "
        f"{y_pred:<18.6f} "
        f"{y_corr:<18.6f}"
    )

print("=" * 70)

print(f"\nFinal Result: y({xf:.4f}) = {y_vals[-1]:.6f}")

# Display all calculated values
print("\nFinal Value Table")
print("-" * 50)
print(f"{'x':<12}{'y':<18}{'f(x,y)':<18}")

for i in range(len(x_vals)):
    print(
        f"{x_vals[i]:<12.4f}"
        f"{y_vals[i]:<18.6f}"
        f"{f(x_vals[i], y_vals[i]):<18.6f}"
    )

# Plot graph
plt.plot(x_vals, y_vals, marker='o', label="Milne Method")
plt.xlabel("x")
plt.ylabel("y")
plt.title("Milne's Predictor-Corrector Method")
plt.grid(True)
plt.legend()
plt.show()
