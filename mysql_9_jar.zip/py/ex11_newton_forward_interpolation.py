def forward_interpolation(x, y, value):
    n = len(x)
    diff = [y.copy()]
    for i in range(1, n):
        row = []
        for j in range(n - i):
            row.append(diff[i - 1][j + 1] - diff[i - 1][j])
        diff.append(row)
    h = x[1] - x[0]
    u = (value - x[0]) / h
    result = y[0]
    term = 1
    for i in range(1, n):
        term *= (u - (i - 1))
        term /= i
        result += term * diff[i][0]
    return result


n = int(input("Enter the number of data points: "))
x = []
y = []
print("Enter the x values:")
for i in range(n):
    x.append(float(input(f"x[{i}] = ")))
print("Enter the y values:")
for i in range(n):
    y.append(float(input(f"y[{i}] = ")))
value = float(input("Enter the value of x to interpolate: "))
answer = forward_interpolation(x, y, value)
print(f"\nInterpolated value at x = {value} is {answer:.4f}")

import matplotlib.pyplot as plt
import numpy as np

x_curve = np.linspace(min(x), max(x), 200)
y_curve = [forward_interpolation(x, y, val) for val in x_curve]

plt.plot(x_curve, y_curve, 'b-', label='Forward Interpolation')
plt.plot(x, y, 'ro', label='Given Data Points')
plt.plot(value, answer, 'go', label='Interpolated Point')

plt.xlabel('x')
plt.ylabel('y')
plt.title('Newton Forward Interpolation')
plt.legend()
plt.grid()
plt.show()
