import numpy as np
import matplotlib.pyplot as plt

n = 20
x = [0.0, 0.6, 1.5, 1.7, 1.9, 2.1, 2.3, 2.6, 2.8, 3.0, 3.6, 4.7, 5.2, 5.7, 5.8, 6.0, 6.4, 6.9, 7.6, 8.0]
y = [-0.8, -0.34, 0.59, 0.59, 0.23, 0.1, 0.28, 1.03, 1.5, 1.44, 0.74, -0.82, -1.27, -0.92, -0.92, -1.04, -0.79, -0.06, 1.0, 0.0]
m = n - 1
h = []
for i in range(m):
    h.append(x[i + 1] - x[i])
A = [[0.0 for j in range(n)] for i in range(n)]
B = [0.0 for i in range(n)]
A[0][0] = 1
A[n - 1][n - 1] = 1
for i in range(1, n - 1):
    A[i][i - 1] = h[i - 1]
    A[i][i] = 2 * (h[i - 1] + h[i])
    A[i][i + 1] = h[i]
    B[i] = 3 * ((y[i + 1] - y[i]) / h[i] - (y[i] - y[i - 1]) / h[i - 1])
for i in range(n):
    for j in range(i + 1, n):
        factor = A[j][i] / A[i][i]
        for k in range(i, n):
            A[j][k] = A[j][k] - factor * A[i][k]
        B[j] = B[j] - factor * B[i]
c = [0.0 for i in range(n)]
for i in range(n - 1, -1, -1):
    sum_value = 0
    for j in range(i + 1, n):
        sum_value += A[i][j] * c[j]
    c[i] = (B[i] - sum_value) / A[i][i]
a = y[:-1]
b = [0.0 for i in range(m)]
d = [0.0 for i in range(m)]
for i in range(m):
    b[i] = ((y[i + 1] - y[i]) / h[i] - h[i] * (2 * c[i] + c[i + 1]) / 3)
    d[i] = (c[i + 1] - c[i]) / (3 * h[i])
print("\nCubic Spline Equations:")
for i in range(m):
    print(f"S{i+1}(x) = {a[i]:.4f} " f"+ {b[i]:.4f}(x - {x[i]:.4f}) "
          f"+ {c[i]:.4f}(x - {x[i]:.4f})^2 " f"+ {d[i]:.4f}(x - {x[i]:.4f})^3")
x_plot = []
y_plot = []
for i in range(m):
    for j in range(50):
        xp_plot = x[i] + j * h[i] / 50
        dx = xp_plot - x[i]
        yp_plot = (a[i] + b[i] * dx + c[i] * dx**2 + d[i] * dx**3)
        x_plot.append(xp_plot)
        y_plot.append(yp_plot)
plt.plot(x_plot, y_plot, 'b-')
plt.scatter(x, y, color='red')
plt.xlabel("x")
plt.ylabel("y")
plt.title("Cubic Spline Interpolation")
plt.grid()
plt.show()
