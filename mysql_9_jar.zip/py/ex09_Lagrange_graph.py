import numpy as np
import matplotlib.pyplot as plt

# Input number of points
n = int(input("Enter number of points: "))

x_pts = []
y_pts = []

# Input data points
print("Enter points as x y:")
for i in range(n):
    x, y = map(float, input(f"Point {i+1}: ").split())
    x_pts.append(x)
    y_pts.append(y)

x_target = float(input("Enter x to interpolate: "))

# Lagrange Interpolation Function
def lagrange(x, x_pts, y_pts):
    result = 0.0

    for i in range(len(x_pts)):
        L = 1.0

        for j in range(len(x_pts)):
            if i != j:
                L *= (x - x_pts[j]) / (x_pts[i] - x_pts[j])

        result += y_pts[i] * L

    return result

# Calculate interpolated value
result = lagrange(x_target, x_pts, y_pts)

print(f"\nInterpolated Value P({x_target}) = {result:.6f}")

# Generate points for smooth curve
x_curve = np.linspace(min(x_pts), max(x_pts), 200)
y_curve = [lagrange(x, x_pts, y_pts) for x in x_curve]

# Plot graph
plt.plot(x_curve, y_curve, label="Lagrange Interpolation")
plt.scatter(x_pts, y_pts, color='red', label="Given Points")
plt.scatter(x_target, result, color='green',
            label="Interpolated Point")

plt.xlabel("X values")
plt.ylabel("Y values")
plt.title("Lagrange Interpolation Graph")
plt.legend()
plt.grid(True)
plt.show()