
import matplotlib.pyplot as plt
import math

def gauss_seidel():
    n = int(input("Enter size of system (n): "))

    print("\nEnter matrix A:")
    A = []
    for i in range(n):
        row = list(map(float, input(f"Row {i+1}: ").split()))
        A.append(row)

    print("\nEnter vector b:")
    b = list(map(float, input(f"b ({n} values): ").split()))

    # Check diagonal elements
    for i in range(n):
        if A[i][i] == 0:
            print("Diagonal element cannot be zero.")
            return

    # Check diagonal dominance
    for i in range(n):
        if abs(A[i][i]) <= sum(abs(A[i][j]) for j in range(n) if j != i):
            print("Warning: Matrix is not strictly diagonally dominant.")
            break

    x0 = [0.0] * n

    TOL = 0.0001
    KMAX = 1000

    Oldx = list(x0)
    Newx = list(x0)

    errors = []
    iterations = []

    TAG = True
    k = 1

    print(f"\nInitial Guess x(0): {Oldx}\n")

    while k <= KMAX and TAG:

        for i in range(n):
            sum1 = sum(A[i][j] * Newx[j] for j in range(i))
            sum2 = sum(A[i][j] * Oldx[j] for j in range(i + 1, n))

            Newx[i] = (b[i] - sum1 - sum2) / A[i][i]

        error = max(abs(Newx[i] - Oldx[i]) for i in range(n))

        # Check divergence
        if not math.isfinite(error) or error > 1e100:
            print("\n[STOP] Method is diverging.")
            break

        errors.append(error)
        iterations.append(k)

        print(f"Iteration {k}: {[round(val, 5) for val in Newx]} | Error: {error:.6f}")

        if error <= TOL:
            TAG = False
            print(f"\n[SUCCESS] Converged at iteration {k}")
        else:
            Oldx = list(Newx)

        k += 1

    if TAG and k > KMAX:
        print("\n[STOP] Maximum iterations reached.")

    if TAG:
        print("\nNo converged solution obtained.")

    if errors:
        print("\nLast Approximation:")
        for i in range(n):
            print(f"x{i+1} = {Newx[i]:.6f}")

        # Plot convergence graph
        plt.plot(iterations, errors, marker='o')
        plt.xlabel("Iteration Number")
        plt.ylabel("Error")
        plt.title("Gauss-Seidel Convergence")
        plt.grid(True)
        plt.tight_layout()
        plt.show()


if __name__ == "__main__":
    gauss_seidel()
