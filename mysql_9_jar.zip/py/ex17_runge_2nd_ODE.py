import math
import re

math_env = {
    "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "exp": math.exp, "sqrt": math.sqrt, "log": math.log,
    "pi": math.pi, "e": math.e
}

def clean_expression(raw_expr):
    # If user entered an equation like "y'' = x**3 - y**2 * z", keep only the right-hand side
    if "=" in raw_expr:
        raw_expr = raw_expr.split("=")[-1]
    
    # Replace y' or y_prime with z
    expr = raw_expr.replace("y'", "z").replace("y_prime", "z")
    
    # Insert missing '*' between closing parenthesis and a variable/number: e.g., (y**2)z -> (y**2)*z
    expr = re.sub(r'(\))\s*([a-zA-Z0-9(])', r'\1*\2', expr)
    # Insert missing '*' between a number and a variable/parenthesis: e.g., 2x -> 2*x
    expr = re.sub(r'(\d)\s*([a-zA-Z(])', r'\1*\2', expr)
    
    return expr.strip()

print("=== 2nd-Order ODE Solver (Coupled RK4) ===")
print("System: y' = z,  z' = y'' = f(x, y, z)")

raw_input_expr = input("\nEnter expression for y'' (you can use x, y, and z or y'): ")
parsed_expr = clean_expression(raw_input_expr)
print(f"Interpreted equation: z' = {parsed_expr}")

def f1(x_val, y_val, z_val):
    return z_val  # dy/dx = z

def f2(x_val, y_val, z_val):
    env = math_env.copy()
    env["x"] = x_val
    env["y"] = y_val
    env["z"] = z_val
    return eval(parsed_expr, {"__builtins__": {}}, env)

# Initial values
x0 = float(input("\nEnter initial x (x0): "))
y0 = float(input("Enter initial y (y0): "))
z0 = float(input("Enter initial y' or z (z0): "))
h = float(input("Enter step size (h): "))
xn = float(input("Enter target x: "))

x, y, z = x0, y0, z0
step = 0

header_z = "y' (z)"
print(f"\n{'Step':<6} {'x':<10} {'y':<14} {header_z:<14}")
print("-" * 46)
print(f"{step:<6} {x:<10.4f} {y:<14.6f} {z:<14.6f}")

x_vals = [x]
y_vals = [y]

while x + h <= xn + 1e-9:
    # Slopes for dy/dx = z
    k1 = h * f1(x, y, z)
    # Slopes for dz/dx = f2(x, y, z)
    l1 = h * f2(x, y, z)

    k2 = h * f1(x + h / 2.0, y + k1 / 2.0, z + l1 / 2.0)
    l2 = h * f2(x + h / 2.0, y + k1 / 2.0, z + l1 / 2.0)

    k3 = h * f1(x + h / 2.0, y + k2 / 2.0, z + l2 / 2.0)
    l3 = h * f2(x + h / 2.0, y + k2 / 2.0, z + l2 / 2.0)

    k4 = h * f1(x + h, y + k3, z + l3)
    l4 = h * f2(x + h, y + k3, z + l3)

    # RK4 update formulas
    y += (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
    z += (l1 + 2 * l2 + 2 * l3 + l4) / 6.0
    x += h
    step += 1
    x_vals.append(x)
    y_vals.append(y)
    print(f"{step:<6} {x:<10.4f} {y:<14.6f} {z:<14.6f}")
    

import matplotlib.pyplot as plt

plt.figure(figsize=(8, 5))
plt.plot(x_vals, y_vals, 'ro-', label="y(x)")

plt.xlabel("x")
plt.ylabel("y")
plt.title("Second-Order ODE - Coupled RK4 Method")
plt.legend()
plt.grid(True)
plt.show()
